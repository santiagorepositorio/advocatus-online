;(window.webpackJsonp = window.webpackJsonp || []).push([
  [6],
  {
    477: function (e, t, o) {
      var content = o(540)
      content.__esModule && (content = content.default),
        'string' == typeof content && (content = [[e.i, content, '']]),
        content.locals && (e.exports = content.locals)
      ;(0, o(22).default)('b1c6581a', content, !0, { sourceMap: !1 })
    },
    539: function (e, t, o) {
      'use strict'
      o(477)
    },
    540: function (e, t, o) {
      var n = o(21)(function (i) {
        return i[1]
      })
      n.push([
        e.i,
        '.message-box .v-text-field__details{display:none}.chat-box{height:80vh;overflow-y:scroll}.message-card{max-width:60%}.chat-list{height:85vh}.wpp-bg{background-image:url(/bg-whatsapp.png);background-repeat:repeat;border-color:#efeae2}.img-msg{max-width:300px}',
        '',
      ]),
        (n.locals = {}),
        (e.exports = n)
    },
    559: function (e, t, o) {
      'use strict'
      o.r(t)
      var n = o(553),
        r = o(552),
        l = o(475),
        c = o(200),
        d = o(198),
        m = o(133),
        h = o(69),
        v = o(201),
        f = o(551),
        _ = o(480),
        y = (o(209), o(26), o(53), o(1)),
        w = o(537)
      window.Pusher = o(538)
      var x = {
          data: function () {
            return {
              selected: [2],
              items: [],
              messages: [],
              message: '',
              selectedChat: {},
            }
          },
          created: function () {
            this.loadMessages()
          },
          mounted: function () {
            var e = this
            ;(window.Echo = new w.a({
              broadcaster: 'pusher',
              key: 'e39fdc2658d60da751bf',
              cluster: 'sa1',
              forceTLS: !0,
            })),
              window.Echo.channel('webhooks').listen('Webhook', function (t) {
                var o,
                  n = null == t ? void 0 : t.message,
                  r = null == t ? void 0 : t.change
                if (
                  (null === (o = e.selectedChat) || void 0 === o
                    ? void 0
                    : o.wa_id) === n.wa_id
                )
                  if (!1 === r) e.appendMessage(n), e.scrollToBottom()
                  else {
                    var l,
                      c =
                        null === (l = e.messages) || void 0 === l
                          ? void 0
                          : l.findIndex(function (e) {
                              return e.wam_id === n.wam_id
                            })
                    ;-1 !== c && y.a.set(e.messages, c, n)
                  }
              })
          },
          methods: {
            checkHeaderImage: function (e) {
              var t
              return (
                'IMAGE' ===
                (null === (t = e.data) || void 0 === t ? void 0 : t.header_type)
              )
            },
            appendMessage: function (e) {
              this.messages = this.messages.concat(e)
            },
            loadMessages: function () {
              var e = this
              this.$axios.get('/messages').then(function (t) {
                var data = t.data
                e.items = data.data
              })
            },
            loadConversation: function (e) {
              var t = this
              ;(this.selectedChat = e),
                this.$axios.get('/messages/' + e.wa_id).then(function (e) {
                  var data = e.data
                  ;(t.messages = data.data), t.scrollToBottom()
                })
            },
            sendMessage: function () {
              var e = this,
                t = { wa_id: this.selectedChat.wa_id, body: this.message }
              this.$axios
                .post('/messages', t)
                .then(function (t) {
                  var data = t.data
                  e.messages.push({
                    outgoing: data.data.outgoing,
                    body: data.data.body,
                    created_at: e.$moment(data.data.created_at).format('L'),
                    status: data.data.status,
                    wam_id: data.data.wam_id,
                  }),
                    (e.message = ''),
                    e.scrollToBottom()
                })
                .catch(function (e) {
                  console.log(e)
                })
            },
            scrollToBottom: function () {
              var e = this
              setTimeout(function () {
                var t = e.$el.querySelector('.chat-box')
                null != t &&
                  t.scrollHeight &&
                  (t.scrollTop = null == t ? void 0 : t.scrollHeight)
              }, 100)
            },
            formatReadStatus: function (e) {
              var t = {
                read: { color: 'blue', icon: 'mdi-check-all', tooltip: 'Read' },
                delivered: {
                  color: 'grey',
                  icon: 'mdi-check-all',
                  tooltip: 'Delivered',
                },
                sent: { color: 'grey', icon: 'mdi-check', tooltip: 'Sent' },
                failed: {
                  color: 'red',
                  icon: 'mdi-alert-circle',
                  tooltip: 'Failed',
                },
              }
              return null != t && t[e]
                ? t[e]
                : {
                    color: 'grey',
                    icon: 'mdi-cards-diamond-outline',
                    tooltip: '',
                  }
            },
          },
        },
        k = (o(539), o(92)),
        component = Object(k.a)(
          x,
          function () {
            var e = this,
              t = e._self._c
            return t(
              f.a,
              [
                t(
                  r.a,
                  { attrs: { sm: '3' } },
                  [
                    t(
                      n.a,
                      { staticClass: 'chat-list', attrs: { elevation: '7' } },
                      [
                        t(
                          n.a,
                          {
                            staticClass: 'pa-2',
                            attrs: { color: '#424242', dark: '' },
                          },
                          [e._v('Chats')]
                        ),
                        e._v(' '),
                        t(
                          d.a,
                          { staticClass: 'py-0', attrs: { 'two-line': '' } },
                          [
                            t(
                              v.a,
                              {
                                attrs: { 'active-class': 'green--text' },
                                model: {
                                  value: e.selected,
                                  callback: function (t) {
                                    e.selected = t
                                  },
                                  expression: 'selected',
                                },
                              },
                              [
                                e._l(e.items, function (o, n) {
                                  return [
                                    t(
                                      m.a,
                                      {
                                        key: o.wa_id,
                                        on: {
                                          click: function (t) {
                                            return e.loadConversation(o)
                                          },
                                        },
                                      },
                                      [
                                        [
                                          t(
                                            h.a,
                                            [
                                              t(h.c, {
                                                domProps: {
                                                  textContent: e._s(o.wa_id),
                                                },
                                              }),
                                              e._v(' '),
                                              t(h.b, {
                                                domProps: {
                                                  textContent: e._s(o.body),
                                                },
                                              }),
                                            ],
                                            1
                                          ),
                                        ],
                                      ],
                                      2
                                    ),
                                    e._v(' '),
                                    n < e.items.length - 1
                                      ? t(l.a, { key: n })
                                      : e._e(),
                                  ]
                                }),
                              ],
                              2
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
                e._v(' '),
                t(
                  r.a,
                  { attrs: { md: '9' } },
                  [
                    t(
                      n.a,
                      { attrs: { elevation: '7' } },
                      [
                        t(
                          n.a,
                          {
                            staticClass: 'chat-box wpp-bg',
                            attrs: { color: '#efeae2' },
                          },
                          [
                            t(
                              n.a,
                              {
                                staticClass: 'pa-2',
                                attrs: { color: '#424242', dark: '' },
                              },
                              [e._v('Mensajes')]
                            ),
                            e._v(' '),
                            e._l(e.messages, function (o, r) {
                              return t(
                                'div',
                                {
                                  key: r,
                                  class: [
                                    'pa-1',
                                    'd-flex',
                                    { 'justify-start': !o.outgoing },
                                    { 'justify-end': o.outgoing },
                                  ],
                                },
                                [
                                  t(
                                    n.a,
                                    {
                                      staticClass: 'pa-2 ma-2 message-card',
                                      attrs: {
                                        color: o.outgoing
                                          ? 'green accent-1'
                                          : 'white',
                                      },
                                    },
                                    [
                                      t('div', [
                                        'text' == o.type
                                          ? t('div', [e._v(e._s(o.body))])
                                          : 'template' == o.type
                                          ? t('div', [
                                              e.checkHeaderImage(o)
                                                ? t('img', {
                                                    staticClass: 'img-msg',
                                                    attrs: {
                                                      src: o.data.header_url,
                                                    },
                                                  })
                                                : e._e(),
                                              e._v(' '),
                                              t('p', {
                                                staticClass: 'pre-wrap',
                                                domProps: {
                                                  textContent: e._s(o.body),
                                                },
                                              }),
                                            ])
                                          : 'image' == o.type
                                          ? t('div', [
                                              t('img', {
                                                staticClass: 'img-msg',
                                                attrs: { src: o.body },
                                              }),
                                            ])
                                          : 'audio' == o.type
                                          ? t('div', [
                                              t(
                                                'audio',
                                                { attrs: { controls: '' } },
                                                [
                                                  t('source', {
                                                    attrs: {
                                                      src: o.body,
                                                      type: 'audio/ogg',
                                                    },
                                                  }),
                                                  e._v(
                                                    'Your browser does not support the audio element.\n                '
                                                  ),
                                                ]
                                              ),
                                            ])
                                          : 'video' == o.type
                                          ? t('div', [
                                              t(
                                                'video',
                                                {
                                                  attrs: {
                                                    width: '320',
                                                    height: '240',
                                                    controls: '',
                                                  },
                                                },
                                                [
                                                  t('source', {
                                                    attrs: { src: o.body },
                                                  }),
                                                  e._v(
                                                    'Your browser does not support the video tag.\n                '
                                                  ),
                                                ]
                                              ),
                                            ])
                                          : e._e(),
                                        e._v(' '),
                                        t(
                                          'p',
                                          {
                                            staticClass:
                                              'text-right text-subtitle-2 font-italic',
                                          },
                                          [
                                            e._v(
                                              '\n                ' +
                                                e._s(o.created_at) +
                                                '\n                '
                                            ),
                                            t(
                                              c.a,
                                              e._g(
                                                e._b(
                                                  {
                                                    attrs: {
                                                      color: e.formatReadStatus(
                                                        o.status
                                                      ).color,
                                                      small: '',
                                                    },
                                                  },
                                                  'v-icon',
                                                  e.attrs,
                                                  !1
                                                ),
                                                e.on
                                              ),
                                              [
                                                e._v(
                                                  e._s(
                                                    e.formatReadStatus(o.status)
                                                      .icon
                                                  )
                                                ),
                                              ]
                                            ),
                                          ],
                                          1
                                        ),
                                      ]),
                                    ]
                                  ),
                                ],
                                1
                              )
                            }),
                          ],
                          2
                        ),
                        e._v(' '),
                        t(l.a),
                        e._v(' '),
                        t(
                          'div',
                          { staticClass: 'pa-3' },
                          [
                            t(_.a, {
                              staticClass: 'message-box',
                              attrs: {
                                dense: '',
                                outlined: '',
                                'background-color': 'white',
                                'append-outer-icon': 'mdi-send',
                                filled: '',
                                'clear-icon': 'mdi-close-circle',
                                clearable: '',
                                label: 'Escribe el mensaje...',
                                type: 'text',
                              },
                              on: {
                                'click:append-outer': e.sendMessage,
                                keydown: function (t) {
                                  return (!t.type.indexOf('key') &&
                                    e._k(
                                      t.keyCode,
                                      'enter',
                                      13,
                                      t.key,
                                      'Enter'
                                    )) ||
                                    t.ctrlKey ||
                                    t.shiftKey ||
                                    t.altKey ||
                                    t.metaKey
                                    ? null
                                    : (t.preventDefault(),
                                      e.sendMessage.apply(null, arguments))
                                },
                              },
                              model: {
                                value: e.message,
                                callback: function (t) {
                                  e.message = t
                                },
                                expression: 'message',
                              },
                            }),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ],
              1
            )
          },
          [],
          !1,
          null,
          null,
          null
        )
      t.default = component.exports
    },
  },
])
